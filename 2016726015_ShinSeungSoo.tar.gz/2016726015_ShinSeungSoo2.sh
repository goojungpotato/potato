#!/bin/bash

echo "=== print file information ==="
echo "current directory : `pwd` "
echo "the number of elements : `ls -l | grep -v ^total | wc -l` "

